<?php
return [
    'settings' => [
        'telegram_bot' => '7847396908:AAHk9f_oB2kCrVwe5q1YNvfx75aiHd951Qw',
        'telegram_id' => '1620679831',
        'pc_block' => '0',
        'notifications' => '0',
        'shutdown' => '0'
    ]
];
?>